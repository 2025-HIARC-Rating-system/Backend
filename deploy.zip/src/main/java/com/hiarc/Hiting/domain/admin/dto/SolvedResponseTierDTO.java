package com.hiarc.Hiting.domain.admin.dto;

import lombok.Getter;

@Getter
public class SolvedResponseTierDTO {
    private Integer tier;
}
