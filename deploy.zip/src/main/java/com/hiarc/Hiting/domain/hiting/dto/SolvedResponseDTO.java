package com.hiarc.Hiting.domain.hiting.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class SolvedResponseDTO {
    private Integer level;
    private Integer solved;
}
