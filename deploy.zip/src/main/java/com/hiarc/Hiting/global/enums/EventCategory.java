package com.hiarc.Hiting.global.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EventCategory {
    DOUBLE_EVENT, TAG_EVENT
}
