package com.hiarc.Hiting.global.common.apiPayload.code;

import com.hiarc.Hiting.global.common.apiPayload.code.dto.ReasonDTO;

public interface BaseCode {

    public ReasonDTO getReason();
    public ReasonDTO getReasonHttpStatus();

}
